import XCTest
import ARKit
@testable import FilmStar

class SearchScreenUITests: XCTestCase {
    // MARK: - UI
    func testSearchManyButtonExists() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchOneButton = app.buttons["Search many"]
        
        XCTAssert(searchOneButton.exists)
    }


    func testSearchOneButtonExists() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchManyButton = app.buttons["Search one"]
        
        XCTAssert(searchManyButton.exists)
    }
    
    func testSearchTextFieldExists() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchTextField = app.textFields["Search for film.."]
        
        XCTAssert(searchTextField.exists)
    }
    
    func testFilterButtonExists() throws {
        let app = XCUIApplication()
        app.launch()
        
        let filterButton = app.buttons["filterButton"]
        
        XCTAssert(filterButton.exists)
    }

    
    // MARK: - Action
    func testTappingFilterButtonTakeToSearchFiltersScreen() throws {
        let app = XCUIApplication()
        app.launch()
        
        let filterButton = app.buttons["filterButton"]
        filterButton.tap()
        
        let resetButton = app.buttons["filterResetButton"]
        let doneButton = app.buttons["filterDoneButton"]
        
        XCTAssert(resetButton.exists, "filterResetButton does not seem to appear")
        XCTAssert(doneButton.exists, "filterDoneButton does not seem to appear")
    }
    
    // MARK: - FilmDetailsScreen
    func testSearchingForITFilmTakesToFilmDetailsScreen() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchTextField = app.textFields["Search for film.."]
        searchTextField.tap()
        searchTextField.typeText("IT")
        
        let searchOneButton = app.buttons["Search one"]
        searchOneButton.tap()
        
        let filmDetailsScrollView = app.scrollViews["filmDetailsScreenScrollView"]
        XCTAssert(filmDetailsScrollView.exists)
        
    }
    
    func testSearchingForListOfGuardiansThenTappingCellTakesToFilmDetailsScreen() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchTextField = app.textFields["Search for film.."]
        searchTextField.tap()
        searchTextField.typeText("Guardians")
        
        let searchOneButton = app.buttons["Search many"]
        searchOneButton.tap()
        
        let tableCell = app.tables.element(boundBy: 0)
        tableCell.tap()
        
        let filmDetailsScrollView = app.scrollViews["filmDetailsScreenScrollView"]
        XCTAssert(filmDetailsScrollView.exists)
    }
    
    // MARK: - FilmsSearchCollectionScreen
    
    func testSearchingForGuardiansFilmTakesToFilmsSearchCollectionScreen() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchTextField = app.textFields["Search for film.."]
        searchTextField.tap()
        searchTextField.typeText("Guardians")
        
        let searchOneButton = app.buttons["Search many"]
        searchOneButton.tap()
        
        let filmsList = app.tables["filmsList"]
        XCTAssert(filmsList.exists)
    }
    
    func testSearchingForITFilmTakesToFilmsSearchCollectionScreen() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchTextField = app.textFields["Search for film.."]
        searchTextField.tap()
        searchTextField.typeText("Guardians")
        
        let searchOneButton = app.buttons["Search many"]
        searchOneButton.tap()
        
        let filmsCount = app.tables.children(matching: .cell).count
        XCTAssertEqual(filmsCount, 10)
    }
    
    func testAfterSearchingForITFilmTappingGoBackButtonTakesToSearchScreen() throws {
        let app = XCUIApplication()
        app.launch()
        
        let searchTextField = app.textFields["Search for film.."]
        searchTextField.tap()
        searchTextField.typeText("Guardians")

        let searchOneButton = app.buttons["Search many"]
        searchOneButton.tap()

        let goBackButton = app.buttons["goBackButton"]
        goBackButton.tap()
        
        let filmsList = app.tables["filmsList"]
        XCTAssertFalse(filmsList.exists)
    }
    
    // MARK: - PosterARScreen
    
    static let isARExperienceAvailable = ARWorldTrackingConfiguration.supportsFrameSemantics([.personSegmentationWithDepth, .sceneDepth]) && ARWorldTrackingConfiguration.supportsSceneReconstruction(.meshWithClassification)
    
    func testTappingARPosterButtonInFilmDetailsScreenTakesToPosterARScreen() throws {
        if SearchScreenUITests.isARExperienceAvailable {
            let app = XCUIApplication()
            app.launch()
            
            let searchTextField = app.textFields["Search for film.."]
            searchTextField.tap()
            searchTextField.typeText("IT")
            
            let searchOneButton = app.buttons["Search one"]
            searchOneButton.tap()
            
            let arPosterButton = app.buttons["arPosterButton"]
            let _ = arPosterButton.waitForExistence(timeout: 3)
            
            arPosterButton.tap()
        }
    }
    
    // MARK: - FavouritesScreen
    
    func testFavouritesScreenExists() throws {
        let app = XCUIApplication()
        app.launch()
        
        let tabBar = app.tabBars.element
        
        XCTAssert(tabBar.exists)
    }
    
    func testClickingSecondTabBarButtonTakesToFavouritesFilmsScreen() throws {
        let app = XCUIApplication()
        app.launch()
        
        let favouritesTabButton = app.tabBars.buttons.element(boundBy: 1)
        
        favouritesTabButton.tap()
        
        let animatingFavouritesImage = app.images["animatingFavouritesImage"]
        let favouritesFilmHeader = app.staticTexts["favouritesFilmHeader"]
        
        if !favouritesFilmHeader.exists {
            XCTAssert(animatingFavouritesImage.exists)
        } else if !animatingFavouritesImage.exists {
            XCTAssert(favouritesFilmHeader.exists)
        } else {
            XCTFail()
        }
    }
}
