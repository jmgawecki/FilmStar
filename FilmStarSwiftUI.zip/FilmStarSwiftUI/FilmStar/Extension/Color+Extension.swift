import SwiftUI

extension Color {
    static let fsSecondary = Color(uiColor: UIColor(named: "secondaryColour")!)
}
